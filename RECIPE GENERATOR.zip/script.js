const API_KEY = '50f527ddd312429f96842e6ee6cb423c'; // using spoonacular api

async function fetchRecipe(mealType) {
    const response = await fetch(`https://api.spoonacular.com/recipes/random?apiKey=${API_KEY}${mealType ? '&tags=' + mealType : ''}`);
    const data = await response.json();
    return data.recipes[0];
}

function displayRecipe(recipe) {
    document.getElementById('recipe-title').innerText = recipe.title;
    document.getElementById('recipe-category').innerText = recipe.dishTypes.join(', ');

    const ingredientsList = document.getElementById('recipe-ingredients');
    ingredientsList.innerHTML = '';
    recipe.extendedIngredients.forEach(ingredient => {
        const li = document.createElement('li');
        li.innerText = `${ingredient.amount} ${ingredient.unit} ${ingredient.name}`;
        ingredientsList.appendChild(li);
    });

    // Display instructions as plain text
    const stepsContainer = document.getElementById('recipe-steps');
    stepsContainer.innerText = recipe.instructions; // Set instructions directly as plain text
}

document.getElementById('get-recipe-btn').addEventListener('click', async () => {
    const selectedValue = document.getElementById('recipe-select').value;
    let mealType = '';

    if (selectedValue === 'breakfast') {
        mealType = 'breakfast';
    } else if (selectedValue === 'lunch') {
        mealType = 'lunch';
    } else if (selectedValue === 'dinner') {
        mealType = 'dinner';
    } else if (selectedValue === 'surprise') {
        mealType = ''; 
    }

    const recipe = await fetchRecipe(mealType);
    displayRecipe(recipe);
});